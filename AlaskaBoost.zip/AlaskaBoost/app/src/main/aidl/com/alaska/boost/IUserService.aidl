package com.alaska.boost;

// Serviço que roda com a identidade "shell" (via Shizuku) e executa comandos.
interface IUserService {
    // Código reservado pelo Shizuku para destruir o serviço.
    void destroy() = 16777114;

    // Executa um comando no shell e devolve a saída (stdout+stderr).
    String exec(String command) = 1;
}
