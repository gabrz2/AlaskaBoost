package com.alaska.boost

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Alaska Boost: modo jogo para Android usando o Shizuku (sem root).
 *
 * O que faz ao ATIVAR:
 *  1. Fecha (force-stop) apps de terceiros que estão rodando, EXCETO os protegidos e o jogo.
 *  2. Limpa processos em cache (am kill-all).
 *  3. Pede ao sistema o "Game Mode: performance" para o jogo e o "modo de desempenho fixo".
 *  4. Reduz as animações do sistema para 0,5x.
 *  5. Abre o jogo e mostra a RAM livre antes e depois.
 * DESATIVAR desfaz os itens 3 e 4.
 *
 * Limites honestos: sem root não dá para mudar a frequência da CPU diretamente; o sistema ainda
 * pode reduzir o desempenho por temperatura. Apps fechados podem voltar a rodar quando abertos ou por alarmes.
 */
class MainActivity : Activity() {

    private data class AppEntry(val pkg: String, val label: String, val system: Boolean)

    private val prefs by lazy { getSharedPreferences("alaskaboost", MODE_PRIVATE) }
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    private lateinit var statusView: TextView
    private lateinit var logView: TextView
    private lateinit var scroll: ScrollView

    private var service: IUserService? = null
    private var pending: (() -> Unit)? = null

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(packageName, UserService::class.java.name))
            .daemon(false)
            .processNameSuffix("service")
            .debuggable(false)
            .version(1)
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = if (binder != null && binder.pingBinder()) IUserService.Stub.asInterface(binder) else null
            log(if (service != null) "Serviço Shizuku conectado." else "Falha ao conectar o serviço.")
            refreshStatus()
            val action = pending
            pending = null
            if (service != null) action?.invoke()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            refreshStatus()
        }
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { refreshStatus() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        service = null
        refreshStatus()
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, result ->
        log(if (result == PackageManager.PERMISSION_GRANTED) "Permissão do Shizuku concedida." else "Permissão do Shizuku negada.")
        refreshStatus()
    }

    // ------------------------------------------------------------------ ciclo de vida / UI

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refreshStatus()
        log("Pronto. Escolha o jogo, revise os apps protegidos e toque em ATIVAR.")
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
        try {
            if (service != null) Shizuku.unbindUserService(userServiceArgs, connection, true)
        } catch (_: Throwable) {
        }
        executor.shutdown()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun button(text: String, onClick: () -> Unit): Button = Button(this).apply {
        this.text = text
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(8) }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Alaska Boost"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        })
        statusView = TextView(this).apply {
            textSize = 14f
            setPadding(0, dp(8), 0, dp(8))
        }
        root.addView(statusView)

        root.addView(button("1. Conectar ao Shizuku / dar permissão") { connectShizuku() })
        root.addView(button("2. Escolher o jogo") { chooseGame() })
        root.addView(button("3. Apps protegidos (não fechar)") { chooseProtected() })
        root.addView(button("ATIVAR BOOST") { startBoost() }.apply { textSize = 18f })
        root.addView(button("DESATIVAR (restaurar)") { startRestore() })

        logView = TextView(this).apply {
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setPadding(0, dp(12), 0, 0)
        }
        scroll = ScrollView(this).apply {
            addView(logView)
            layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(scroll)
        setContentView(root)
    }

    private fun log(message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        main.post {
            logView.append("[$time] $message\n")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
    }

    private fun toast(message: String) {
        main.post { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    }

    private fun refreshStatus() {
        main.post {
            val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
            val granted = running && try {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } catch (_: Throwable) { false }
            val game = prefs.getString("game", null)
            val protectedCount = prefs.getStringSet("protected", emptySet())?.size ?: 0
            statusView.text = "Shizuku: " + (if (running) "ativo" else "INATIVO (inicie o Shizuku)") +
                "\nPermissão: " + (if (granted) "concedida" else "pendente") +
                "\nServiço: " + (if (service != null) "conectado" else "desconectado") +
                "\nJogo: " + (if (game != null) labelOf(game) else "(nenhum)") +
                "\nApps protegidos por você: $protectedCount"
        }
    }

    // ------------------------------------------------------------------ Shizuku

    private fun connectShizuku() {
        ensureService { log("Tudo conectado.") }
    }

    /** Garante Shizuku ativo + permissão + serviço conectado; depois executa [onReady]. */
    private fun ensureService(onReady: () -> Unit) {
        val running = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
        if (!running) {
            toast("O Shizuku não está em execução. Abra o app Shizuku e inicie-o.")
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Permissão negada no Shizuku. Libere este app nas configurações do Shizuku.")
                return
            }
            Shizuku.requestPermission(1001)
            return
        }
        if (service != null) {
            onReady()
            return
        }
        pending = onReady
        try {
            Shizuku.bindUserService(userServiceArgs, connection)
        } catch (e: Throwable) {
            pending = null
            log("Erro ao conectar o serviço: ${e.message}")
        }
    }

    private fun sh(command: String): String = service?.exec(command) ?: "ERRO: serviço desconectado"

    // ------------------------------------------------------------------ listas de apps

    private fun launchableApps(): List<AppEntry> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return packageManager.queryIntentActivities(intent, 0)
            .map { ri ->
                val ai = ri.activityInfo.applicationInfo
                AppEntry(ai.packageName, ri.loadLabel(packageManager).toString(), (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0)
            }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) {
        pkg
    }

    private fun chooseGame() {
        val apps = launchableApps().filter { it.pkg != packageName }
        val labels = apps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Escolha o jogo")
            .setItems(labels) { _, i ->
                prefs.edit().putString("game", apps[i].pkg).apply()
                log("Jogo: ${apps[i].label}")
                refreshStatus()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun chooseProtected() {
        // Só apps instalados por você podem ser fechados; apps do sistema nunca são tocados.
        val apps = launchableApps().filter { !it.system && it.pkg != packageName }
        if (apps.isEmpty()) {
            toast("Nenhum app de terceiros encontrado.")
            return
        }
        val current = (prefs.getStringSet("protected", emptySet()) ?: emptySet()).toMutableSet()
        val checked = BooleanArray(apps.size) { apps[it].pkg in current || autoProtected(apps[it].pkg) }
        AlertDialog.Builder(this)
            .setTitle("Marque o que NÃO deve ser fechado (entregas, mapas, mensagens...)")
            .setMultiChoiceItems(apps.map { it.label }.toTypedArray(), checked) { _, i, isChecked ->
                if (isChecked) current.add(apps[i].pkg) else current.remove(apps[i].pkg)
            }
            .setPositiveButton("Salvar") { _, _ ->
                prefs.edit().putStringSet("protected", current).apply()
                log("Apps protegidos salvos: ${current.size}")
                refreshStatus()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    /** Proteção automática por nome (lado seguro: proteger a mais nunca atrapalha). */
    private fun autoProtected(pkg: String): Boolean {
        val patterns = listOf("ifood", "uber", "waze", "rappi", "99", "loggi", "lalamove", "whatsapp",
            "telegram", "nubank", "mercadopago", "picpay", "maps", "shizuku")
        return patterns.any { pkg.contains(it, ignoreCase = true) }
    }

    private fun alwaysProtected(): Set<String> {
        val set = mutableSetOf(packageName, "moe.shizuku.privileged.api")
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        @Suppress("DEPRECATION")
        packageManager.resolveActivity(home, 0)?.activityInfo?.packageName?.let { set.add(it) }
        Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
            ?.substringBefore('/')?.let { set.add(it) }
        return set
    }

    // ------------------------------------------------------------------ ATIVAR

    private fun startBoost() {
        val game = prefs.getString("game", null)
        if (game == null) {
            toast("Escolha o jogo primeiro (botão 2).")
            return
        }
        ensureService { prepareBoost(game) }
    }

    private fun prepareBoost(game: String) {
        executor.execute {
            val userProtected = prefs.getStringSet("protected", emptySet()) ?: emptySet()
            val always = alwaysProtected()
            val running = runningProcessPackages()
            val targets = launchableApps()
                .filter { !it.system }
                .filter { it.pkg != game && it.pkg !in always && it.pkg !in userProtected && !autoProtected(it.pkg) }
                .filter { it.pkg in running && Regex("[A-Za-z0-9._]+").matches(it.pkg) }
            main.post { confirmBoost(game, targets) }
        }
    }

    private fun confirmBoost(game: String, targets: List<AppEntry>) {
        val names = targets.take(15).joinToString("\n") { "• ${it.label}" } +
            (if (targets.size > 15) "\n… e mais ${targets.size - 15}" else "")
        val message = if (targets.isEmpty()) "Nenhum app de terceiros para fechar. Aplicar só os ajustes de desempenho?"
        else "Vou fechar ${targets.size} app(s):\n\n$names\n\nApps de entrega/mensagens que você protegeu ficam de fora."
        AlertDialog.Builder(this)
            .setTitle("Confirmar boost")
            .setMessage(message)
            .setPositiveButton("Ativar") { _, _ -> executor.execute { doBoost(game, targets) } }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun runningProcessPackages(): Set<String> {
        val out = sh("ps -A -o NAME")
        return out.lineSequence().map { it.trim().substringBefore(':') }.filter { it.isNotEmpty() }.toSet()
    }

    private fun availableMb(): Long {
        return try {
            File("/proc/meminfo").readLines().firstOrNull { it.startsWith("MemAvailable:") }
                ?.filter { it.isDigit() }?.toLong()?.div(1024) ?: -1
        } catch (_: Exception) {
            -1
        }
    }

    private fun doBoost(game: String, targets: List<AppEntry>) {
        val before = availableMb()
        log("RAM livre antes: $before MB")

        if (targets.isNotEmpty()) {
            sh(targets.joinToString("; ") { "am force-stop ${it.pkg}" })
            log("Apps fechados: ${targets.size}")
        }
        sh("am kill-all")

        // Guarda as escalas de animação originais (uma única vez) e reduz para 0,5x.
        if (!prefs.contains("anim_saved")) {
            val e = prefs.edit()
            for (key in ANIM_KEYS) e.putString("anim_$key", sh("settings get global $key").trim())
            e.putBoolean("anim_saved", true).apply()
        }
        sh(ANIM_KEYS.joinToString("; ") { "settings put global $it 0.5" })
        log("Animações do sistema: 0,5x")

        val gm = sh("cmd game mode performance $game")
        log("Game Mode (performance): " + gm.ifBlank { "ok" }.take(120))
        val fixed = sh("cmd power set-fixed-performance-mode-enabled true")
        log("Modo desempenho fixo: " + fixed.ifBlank { "ok" }.take(120))

        try { Thread.sleep(1500) } catch (_: InterruptedException) { }
        val after = availableMb()
        log("RAM livre depois: $after MB (diferença: ${after - before} MB)")
        log("Obs.: o Android pode reabrir alguns apps sozinho; o ganho de RAM varia.")

        main.post {
            packageManager.getLaunchIntentForPackage(game)?.let {
                it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(it)
            }
        }
    }

    // ------------------------------------------------------------------ DESATIVAR

    private fun startRestore() {
        ensureService {
            executor.execute {
                prefs.getString("game", null)?.let { game ->
                    if (Regex("[A-Za-z0-9._]+").matches(game)) {
                        log("Game Mode (padrão): " + sh("cmd game mode standard $game").ifBlank { "ok" }.take(120))
                    }
                }
                sh("cmd power set-fixed-performance-mode-enabled false")
                val restore = ANIM_KEYS.joinToString("; ") { key ->
                    val saved = prefs.getString("anim_$key", "1.0") ?: "1.0"
                    "settings put global $key ${if (saved == "null" || saved.isBlank()) "1.0" else saved}"
                }
                sh(restore)
                prefs.edit().remove("anim_saved").apply()
                log("Restaurado: Game Mode, desempenho fixo e animações.")
            }
        }
    }

    companion object {
        private val ANIM_KEYS = listOf("window_animation_scale", "transition_animation_scale", "animator_duration_scale")
    }
}
