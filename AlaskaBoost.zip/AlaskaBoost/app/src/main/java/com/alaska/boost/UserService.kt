package com.alaska.boost

import kotlin.system.exitProcess

/**
 * Roda em um processo separado com privilégios de shell, iniciado pelo Shizuku.
 * Só executa comandos enviados pelo próprio app (o Shizuku exige a permissão concedida).
 */
class UserService : IUserService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            // 2>&1 junta stderr e stdout, evitando travar por buffer cheio.
            val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", "($command) 2>&1"))
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output.trim()
        } catch (e: Exception) {
            "ERRO: ${e.message}"
        }
    }
}
